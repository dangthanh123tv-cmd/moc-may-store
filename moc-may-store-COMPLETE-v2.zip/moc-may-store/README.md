# Mộc Mây Store

React + Vite, giao diện nâu/xanh pastel, responsive và Admin demo.

Mật khẩu Admin: `admin123`.

Có: thêm/sửa/xóa sản phẩm, đổi giá/danh mục/mô tả, xem đơn hàng và cập nhật trạng thái, quản lý đánh giá, đổi tên thương hiệu và màu nền.

Dữ liệu demo dùng localStorage nên mỗi thiết bị có dữ liệu riêng.

GitHub Pages: https://dangthanh123tv-cmd.github.io/moc-may-store/
